-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 07, 2013 at 12:22 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cloud`
--

-- --------------------------------------------------------

--
-- Table structure for table `billing_detail`
--

CREATE TABLE IF NOT EXISTS `billing_detail` (
  `id` int(10) NOT NULL,
  `date` date NOT NULL,
  `cpu_usage_charge` float NOT NULL,
  `memory_usage_charge` float NOT NULL,
  `image_charge` float NOT NULL,
  `network_charge` float NOT NULL,
  `hard_disk_charge` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `billing_detail`
--


-- --------------------------------------------------------

--
-- Table structure for table `credential`
--

CREATE TABLE IF NOT EXISTS `credential` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `last_login` varchar(100) NOT NULL,
  `live` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `credential`
--

INSERT INTO `credential` (`id`, `username`, `password`, `last_login`, `live`) VALUES
(1, 'admin', 'gcet', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `host_info`
--

CREATE TABLE IF NOT EXISTS `host_info` (
  `host_name` varchar(100) NOT NULL,
  `total_memory` float NOT NULL,
  `free_memory` float NOT NULL,
  `total_cpu` float NOT NULL,
  `free_cpu` float NOT NULL,
  `total_hard_disk` float NOT NULL,
  `free_hard_disk` float NOT NULL,
  `service_runing` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `host_info`
--


-- --------------------------------------------------------

--
-- Table structure for table `mail_details`
--

CREATE TABLE IF NOT EXISTS `mail_details` (
  `mail_content` varchar(500) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mail_details`
--


-- --------------------------------------------------------

--
-- Table structure for table `resource_usage`
--

CREATE TABLE IF NOT EXISTS `resource_usage` (
  `instance_name` varchar(20) NOT NULL,
  `date` varchar(10) NOT NULL,
  `time` varchar(20) NOT NULL,
  `cpu_usage` float NOT NULL,
  `memory` float NOT NULL,
  `txby` float NOT NULL,
  `rxby` float NOT NULL,
  `wrrq` float NOT NULL,
  `rdrq` float NOT NULL,
  `hard_disk_used` float NOT NULL,
  `host` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `resource_usage`
--


-- --------------------------------------------------------

--
-- Table structure for table `unit_price`
--

CREATE TABLE IF NOT EXISTS `unit_price` (
  `resource_name` varchar(100) NOT NULL,
  `price_per` varchar(100) NOT NULL,
  `price` float NOT NULL,
  `primary_cost` float NOT NULL,
  `unit` varchar(100) NOT NULL,
  `id` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `unit_price`
--

INSERT INTO `unit_price` (`resource_name`, `price_per`, `price`, `primary_cost`, `unit`, `id`) VALUES
('CPU (processing Power)', '1 ', 0.5, 0, '1 Ghz', 1),
('RAM (Memory) ', '1 ', 0.2, 0, '1 Gb', 2),
('Hard Disk', '1', 0.2, 0, '10 Gb', 3),
('Network Bandwidth', '1 ', 0.1, 0, '1 Mbps', 4),
('Image', '1', 0.1, 0.3, 'Linus', 5);
